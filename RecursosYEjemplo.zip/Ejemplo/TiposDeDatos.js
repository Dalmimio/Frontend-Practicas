// TIPOS DE DATOS

let nombre = "Juan" // String/ char
let edad = 18 // Numero, INT, FLOAT (numeros con decimales)
let esMayor = true // BOOLEAN -> acepta TRUE, FALSE

// OBJETO
let Persona = {
    // nombre:valor
    nombre:"Juan",
    edad: 5,
    esMayor: false,
    tieneMascota: true,
    // Vector/Array -> PERMITEN AGREGAR MUCHOS VALORES DEL MISMO TIPO A UNA VARIABLE
    frutasFav: ["manzana", "uvas", "peras"],
    equiposFav: ["River", "Boca", "Barcelona FC"]
}

// Las posiciones empiezan desde 0
var productos = ["manzana", "uvas", "peras", "tomate", "rabano", "uvas verdes"]

// Variable Constante
const PI = 3.14
// tipoof -> VERIFICA EL VALOR DE UNA VARIABLE 
console.log("El tipo de dato de la variable frutasFav es: " + typeof(productos))

console.log("El se llama " + Persona.nombre + " tiene " + Persona.edad + " años")
// length -> permite ver el numero de elementos
console.log("La variable productos tiene " + productos.length + " elementos")
console.log("El producto 5 es: " + productos[4])

// SUMA RESTA MULTIPLICACION Y DIVISION
let num1 = 3
let num2 = 23
let num3 = 9

// suma entre num1 y num3
let suma = num1 + num3
console.log("La suma de " + num1 + " + " + num3 + " = " +  suma)




// resta entre num2 y num3
let resta = num1 - num3
console.log("La resta de " + num1 + " - " + num3 + " = " +  resta)

// multiplicacion entre num1 y num3
let multiplicacion = num1 * num3
console.log("La multiplicacion de " + num1 + " * " + num3 + " = " +  multiplicacion)

// division entre num1 y num3
let division = num1 / num3
console.log("La division de " + num1 + " / " + num3 + " = " +  division)

// resto entre num1 y num3
let resto = num1 % num3
console.log("El resto de la division de " + num1 + " / " + num3 + " = " +  resto)



// console.log("Hola mundo")

// console.log("ahre")

let numero1 = prompt("Ingrese numero uno: ");
let numero2 = prompt("Ingrese numero dos: ");


console.log("Numero 1: " + numero1 + " Numero 2: " + numero2)


// if else
// switch
// for
// do while
// while 