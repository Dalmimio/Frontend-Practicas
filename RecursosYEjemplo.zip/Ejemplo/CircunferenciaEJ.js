// Calcula la circunferencia de un circulo que tiene diametro de 3
// Formula = Circunferencia = PI * diametro

const PI = 3.14
let diametro = 3
let circunferencia = PI*diametro


// GUARDARLO EN UNA VARIABLE Y MOSTRARLO DESDE ELLA
console.log("La circunferencia del circulo es de: " + circunferencia)
// PUEDO REALIZAR EL CALCULO DIRECTO EN LA CONSOLA
console.log("La circunferencia del circulo es de: " + (PI*diametro))

